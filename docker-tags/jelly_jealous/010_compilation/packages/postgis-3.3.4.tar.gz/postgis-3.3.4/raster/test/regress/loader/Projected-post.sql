-- "loadedrast" is removed automatically !
DROP TABLE o_2_loadedrast;
