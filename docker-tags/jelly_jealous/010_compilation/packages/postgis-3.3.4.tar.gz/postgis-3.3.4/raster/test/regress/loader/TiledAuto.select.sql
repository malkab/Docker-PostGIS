select count(*) from loadedrast;
